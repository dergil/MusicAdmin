package mediaDB;

public interface Licensed extends Content{
    String getHolder();
}
