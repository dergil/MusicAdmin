package mediaDB;

public enum Tag {
    Animal,Tutorial,Lifestyle,News
}
