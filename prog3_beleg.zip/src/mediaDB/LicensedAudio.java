package mediaDB;

public interface LicensedAudio extends Licensed,Audio {
}
