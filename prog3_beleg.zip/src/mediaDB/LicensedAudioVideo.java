package mediaDB;

public interface LicensedAudioVideo extends Licensed,AudioVideo {}
