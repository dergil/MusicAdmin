package mediaDB;

public interface AudioVideo extends Audio,Video {}
