package mediaDB;

public interface InteractiveVideo extends Video,Interactive {}
