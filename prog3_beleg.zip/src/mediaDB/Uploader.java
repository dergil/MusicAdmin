package mediaDB;

public interface Uploader {
    String getName();
}
