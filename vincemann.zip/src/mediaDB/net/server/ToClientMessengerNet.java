package mediaDB.net.server;

public class ToClientMessengerNet {
//    ObjectOutputStream out;
//
//    public void producerNotListet() throws IOException {
//        sendResponse("Produzent der Datei nicht gelistet.");
//    }
//
//    public void fileNotListet() throws IOException {
//        sendResponse("Datei nicht gelistet.");
//    }
//
//
//    public void list(String list) throws IOException {
//        sendResponse(list);
//    }
//
//    public void sendString(String response) throws IOException {
//        sendResponse(response);
//    }
//
//    public void sendResponse(String response) throws IOException {
//        out.writeObject(new ServerResponseEvent(this, response));
//    }
//
//    public void setOut(ObjectOutputStream out) {
//        this.out = out;
//    }
}
