package mediaDB.domain_logic.file_interfaces;

public interface Licensed extends Content{
    String getHolder();
}
