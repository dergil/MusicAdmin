package mediaDB.domain_logic.file_interfaces;

public interface LicensedAudioVideo extends Licensed,AudioVideo {}
