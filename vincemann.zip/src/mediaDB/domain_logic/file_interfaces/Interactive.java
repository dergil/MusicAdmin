package mediaDB.domain_logic.file_interfaces;

public interface Interactive extends Content {
    String getType();
}
