package mediaDB.domain_logic.file_interfaces;

public interface AudioVideo extends Audio,Video {}
