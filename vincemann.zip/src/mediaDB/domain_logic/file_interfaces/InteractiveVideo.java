package mediaDB.domain_logic.file_interfaces;

public interface InteractiveVideo extends Video,Interactive {}
