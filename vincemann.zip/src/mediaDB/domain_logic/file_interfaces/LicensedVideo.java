package mediaDB.domain_logic.file_interfaces;

public interface LicensedVideo extends Licensed,Video {}
