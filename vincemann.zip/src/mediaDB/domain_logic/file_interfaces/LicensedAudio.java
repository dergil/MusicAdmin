package mediaDB.domain_logic.file_interfaces;

public interface LicensedAudio extends Licensed,Audio {
}
