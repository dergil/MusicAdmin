package mediaDB.domain_logic.enums;

public enum Tag {
    Animal,Tutorial,Lifestyle,News
}
