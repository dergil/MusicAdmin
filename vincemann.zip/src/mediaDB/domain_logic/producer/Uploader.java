package mediaDB.domain_logic.producer;

public interface Uploader {
    String getName();
}
