package mediaDB.domain_logic.observables;

public class ChangeInDomainLogic {
//    String type;
//    String address;
//
//    public ChangeInDomainLogic(String type, String address) {
//        this.type = type;
//        this.address = address;
//    }
//
//    public synchronized String getType() {
//        return type;
//    }
//
//    public synchronized String getAddress() {
//        return address;
//    }
}
