package mediaDB.routing;

public interface NetworkEvent {
    String getEventName();
    String getSender();
}
