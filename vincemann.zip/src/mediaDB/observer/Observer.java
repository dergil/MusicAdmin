package mediaDB.observer;

public interface Observer {
    void update();
}
