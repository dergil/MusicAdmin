package mediaDB.ui;

public class Numerical {
    public static boolean isNumerical (String input){
        return input.matches("[0-9]+");
    }
}
