package mediaDB.ui.cli.modes;

import java.io.IOException;

public interface CLIMode {
    void start() throws IOException;
}
