package mediaDB.ui.cli.modes;

import mediaDB.net.client.ClientEventBus;
import mediaDB.routing.EventListener;
import mediaDB.routing.NetworkEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ObjectOutputStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;

class ConfigModeTest {
    ConfigMode configMode;

//TODO:später
    @BeforeEach
    void setUp() {

    }

    @Test
    void start() {
    }
}